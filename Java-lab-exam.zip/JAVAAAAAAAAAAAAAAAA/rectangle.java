class Rectangle {

    // Private data members
    private double length;
    private double breadth;

    // Public method to set values
    public void setDimensions(double l, double b) {
        length = l;
        breadth = b;
    }

    // Public method to calculate area
    public double calculateArea() {
        return length * breadth;
    }

    // Public method to display rectangle details
    public void display() {
        System.out.println("Length: " + length);
        System.out.println("Breadth: " + breadth);
        System.out.println("Area of Rectangle: " + calculateArea());
    }
}

public class rectangle {

    public static void main(String[] args) {

        // Creating Rectangle object
        Rectangle rect = new Rectangle();

        // Setting dimensions
        rect.setDimensions(10, 5);

        // Displaying details and area
        rect.display();
    }
}