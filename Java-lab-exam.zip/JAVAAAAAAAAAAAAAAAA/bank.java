class BankAccount {

    // Private data members
    private int accountNumber;
    private String accountHolder;
    private double balance;

    // Method to initialize account details
    public void setAccountDetails(int accNo, String name, double bal) {
        accountNumber = accNo;
        accountHolder = name;
        balance = bal;
    }

    // Method to deposit money
    public void deposit(double amount) {
        balance = balance + amount;
        System.out.println(amount + " deposited successfully.");
    }

    // Method to withdraw money
    public void withdraw(double amount) {
        if (amount <= balance) {
            balance = balance - amount;
            System.out.println(amount + " withdrawn successfully.");
        } else {
            System.out.println("Insufficient balance.");
        }
    }

    // Method to display account details
    public void displayBalance() {
        System.out.println("\nAccount Details:");
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + accountHolder);
        System.out.println("Current Balance: " + balance);
    }
}

public class bank {

    public static void main(String[] args) {

        // Creating BankAccount object
        BankAccount acc = new BankAccount();

        // Setting account details
        acc.setAccountDetails(1001, "Rahul", 5000);

        // Depositing money
        acc.deposit(2000);

        // Withdrawing money
        acc.withdraw(1500);

        // Displaying final balance
        acc.displayBalance();
    }
}