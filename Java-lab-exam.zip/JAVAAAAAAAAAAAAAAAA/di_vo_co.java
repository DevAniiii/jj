import java.util.Scanner;

public class di_vo_co {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input string
        System.out.print("Enter a string: ");
        String str = sc.nextLine();

        int digits = 0;
        int vowels = 0;
        int consonants = 0;

        // Convert string to lowercase
        str = str.toLowerCase();

        // Loop through each character
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);

            // Check digit
            if (Character.isDigit(ch)) {
                digits++;
            }
            // Check vowel
            else if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowels++;
            }
            // Check consonant
            else if (Character.isLetter(ch)) {
                consonants++;
            }
        }

        // Display results
        System.out.println("Number of digits: " + digits);
        System.out.println("Number of vowels: " + vowels);
        System.out.println("Number of consonants: " + consonants);

        sc.close();
    }
}