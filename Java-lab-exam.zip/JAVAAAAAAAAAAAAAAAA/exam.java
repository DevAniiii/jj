// Java Program to Manage Student Examination Results

class Student {
    int rollNo;
    String name;

    // Constructor
    Student(int rollNo, String name) {
        this.rollNo = rollNo;
        this.name = name;
    }

    // Method to display result
    void displayResult() {
        System.out.println("Student Result");
    }
}

// Derived class
class Result extends Student {

    int[] marks;
    int total = 0;
    double percentage;
    String grade;

    // Constructor
    Result(int rollNo, String name, int[] marks) {
        super(rollNo, name);
        this.marks = marks;
    }

    // Method to calculate result
    void calculateResult() {

        // Calculate total
        for (int mark : marks) {
            total += mark;
        }

        // Calculate percentage
        percentage = (double) total / marks.length;

        // Assign grade
        if (percentage >= 90) {
            grade = "A+";
        } else if (percentage >= 75) {
            grade = "A";
        } else if (percentage >= 60) {
            grade = "B";
        } else if (percentage >= 40) {
            grade = "C";
        } else {
            grade = "Fail";
        }
    }

    // Overriding displayResult()
    @Override
    void displayResult() {

        calculateResult();

        String line = "===================================";

        System.out.println(line);
        System.out.println("        RESULT SHEET");
        System.out.println(line);

        System.out.println("Roll Number : " + rollNo);
        System.out.println("Student Name: " + name);

        System.out.print("Marks       : ");

        // Display marks using string operations
        String markString = "";

        for (int mark : marks) {
            markString += mark + " ";
        }

        System.out.println(markString);

        System.out.println("Total Marks : " + total);
        System.out.println("Percentage  : " + percentage + "%");
        System.out.println("Grade       : " + grade);

        System.out.println(line);
    }
}

// Main class
public class exam {

    public static void main(String[] args) {

        int[] marks = {85, 90, 78, 88, 92};

        Result r1 = new Result(101, "Rahul", marks);

        r1.displayResult();
    }
}