// File: ClassA.java

package mypackage;

public class classA {

    // Public member
    public int publicVar = 10;

    // Default member
    int defaultVar = 20;

    // Private member
    private int privateVar = 30;

    // Public method
    public void showData() {
        System.out.println("Public Variable: " + publicVar);
        System.out.println("Default Variable: " + defaultVar);
        System.out.println("Private Variable: " + privateVar);
    }
}