// File: ClassB.java

package mypackage;

public class classB {

    public static void main(String[] args) {

        // Creating object of ClassA
        classA obj = new classA();

        // Accessible members
        System.out.println("Accessing Public Variable: " + obj.publicVar);
        System.out.println("Accessing Default Variable: " + obj.defaultVar);

        // Not accessible because it is private
        // System.out.println(obj.privateVar); // Error

        // Accessing public method
        obj.showData();
    }
}