class VariableDemo {

    // Instance variable
    int instanceVar = 100;

    // Method demonstrating local variable
    void showVariables() {

        // Local variable
        int localVar = 50;

        System.out.println("Instance Variable: " + instanceVar);
        System.out.println("Local Variable: " + localVar);
    }
}

public class variable {

    public static void main(String[] args) {

        // Creating object
        VariableDemo obj = new VariableDemo();

        // Calling method
        obj.showVariables();
    }
}