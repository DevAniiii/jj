import java.util.Scanner;

public class datatype {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter int value: ");
        int i = sc.nextInt();

        System.out.print("Enter float value: ");
        float f = sc.nextFloat();

        System.out.print("Enter double value: ");
        double d = sc.nextDouble();

        System.out.print("Enter char value: ");
        char c = sc.next().charAt(0);

        System.out.print("Enter boolean value: ");
        boolean b = sc.nextBoolean();

        System.out.println("\n--- Output ---");
        System.out.println("Integer : " + i);
        System.out.println("Float   : " + f);
        System.out.println("Double  : " + d);
        System.out.println("Character : " + c);
        System.out.println("Boolean : " + b);

        sc.close();
    }
}