class Student {

    // Data members
    int rollNo;
    String name;
    float marks;

    // Method to assign values
    void setData(int r, String n, float m) {
        rollNo = r;
        name = n;
        marks = m;
    }

    // Method to display student details
    void display() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
        System.out.println();
    }
}

public class student {

    public static void main(String[] args) {

        // Creating first object
        Student s1 = new Student();
        s1.setData(101, "Rahul", 85.5f);

        // Creating second object
        Student s2 = new Student();
        s2.setData(102, "Anita", 91.0f);

        // Displaying details
        System.out.println("Student Details:");
        s1.display();
        s2.display();
    }
}