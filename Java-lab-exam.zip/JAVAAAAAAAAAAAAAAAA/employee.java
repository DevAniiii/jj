class Employee {

    // Private data members
    private int empId;
    private String empName;
    private double salary;

    // Public setter methods
    public void setEmpId(int id) {
        empId = id;
    }

    public void setEmpName(String name) {
        empName = name;
    }

    public void setSalary(double sal) {
        salary = sal;
    }

    // Public getter methods
    public int getEmpId() {
        return empId;
    }

    public String getEmpName() {
        return empName;
    }

    public double getSalary() {
        return salary;
    }
}

public class employee {

    public static void main(String[] args) {

        // Creating Employee object
        Employee emp = new Employee();

        // Setting values using setter methods
        emp.setEmpId(101);
        emp.setEmpName("Rohit");
        emp.setSalary(50000);

        // Accessing values using getter methods
        System.out.println("Employee Details:");
        System.out.println("Employee ID: " + emp.getEmpId());
        System.out.println("Employee Name: " + emp.getEmpName());
        System.out.println("Salary: " + emp.getSalary());
    }
}