// Java Program to Manage Student Records using ArrayList

import java.util.ArrayList;
import java.util.Iterator;

class Student {

    int rollNo;
    String name;
    double marks;

    // Constructor
    Student(int rollNo, String name, double marks) {
        this.rollNo = rollNo;
        this.name = name;
        this.marks = marks;
    }

    // Method to display student details
    void display() {
        System.out.println("Roll No : " + rollNo);
        System.out.println("Name    : " + name);
        System.out.println("Marks   : " + marks);
        System.out.println("-----------------------");
    }
}

public class studentarray {

    public static void main(String[] args) {

        // Create ArrayList
        ArrayList<Student> studentList = new ArrayList<Student>();

        // Adding students
        studentList.add(new Student(101, "Rahul", 85));
        studentList.add(new Student(102, "Amit", 90));
        studentList.add(new Student(103, "Priya", 78));

        System.out.println("STUDENT RECORDS");
        System.out.println("===================");

        // Display using for-each loop
        for (Student s : studentList) {
            s.display();
        }

        // Search student by roll number
        int searchRoll = 102;
        boolean found = false;

        System.out.println("Searching Student with Roll No: "
                + searchRoll);

        for (Student s : studentList) {

            if (s.rollNo == searchRoll) {

                System.out.println("Student Found!");
                s.display();
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Student Not Found!");
        }

        // Remove student
        int removeRoll = 103;

        Iterator<Student> itr = studentList.iterator();

        while (itr.hasNext()) {

            Student s = itr.next();

            if (s.rollNo == removeRoll) {

                itr.remove();

                System.out.println("Student with Roll No "
                        + removeRoll + " Removed Successfully.");
            }
        }

        // Display all students after removal
        System.out.println("\nUPDATED STUDENT RECORDS");
        System.out.println("===================");

        // Iteration using Iterator
        Iterator<Student> iterator = studentList.iterator();

        while (iterator.hasNext()) {

            Student s = iterator.next();

            s.display();
        }
    }
}