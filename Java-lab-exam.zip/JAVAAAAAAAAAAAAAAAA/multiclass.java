// Java Program using ArrayList, HashSet, and HashMap

import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Map;

public class multiclass {

    public static void main(String[] args) {

        // Using List Interface with ArrayList
        List<String> studentList = new ArrayList<String>();

        // Using Set Interface with HashSet
        Set<String> courseSet = new HashSet<String>();

        // Using Map Interface with HashMap
        Map<String, String> studentCourseMap =
                new HashMap<String, String>();

        // ---------------- ADD OPERATIONS ----------------

        // Add student names
        studentList.add("Rahul");
        studentList.add("Amit");
        studentList.add("Priya");

        // Add course names
        courseSet.add("Java");
        courseSet.add("Python");
        courseSet.add("Database");

        // Duplicate course (will not be stored)
        courseSet.add("Java");

        // Map students with courses
        studentCourseMap.put("Rahul", "Java");
        studentCourseMap.put("Amit", "Python");
        studentCourseMap.put("Priya", "Database");

        // ---------------- DISPLAY OPERATIONS ----------------

        System.out.println("STUDENT LIST");
        System.out.println("================");

        for (String student : studentList) {
            System.out.println(student);
        }

        System.out.println("\nCOURSE LIST");
        System.out.println("================");

        for (String course : courseSet) {
            System.out.println(course);
        }

        System.out.println("\nSTUDENT-COURSE MAPPING");
        System.out.println("================");

        for (Map.Entry<String, String> entry
                : studentCourseMap.entrySet()) {

            System.out.println(entry.getKey()
                    + " -> " + entry.getValue());
        }

        // ---------------- UPDATE OPERATIONS ----------------

        // Update course for Amit
        studentCourseMap.put("Amit", "Java");

        System.out.println("\nAfter Updating Amit's Course:");
        System.out.println("================");

        for (Map.Entry<String, String> entry
                : studentCourseMap.entrySet()) {

            System.out.println(entry.getKey()
                    + " -> " + entry.getValue());
        }

        // ---------------- DELETE OPERATIONS ----------------

        // Remove student
        studentList.remove("Priya");

        // Remove course
        courseSet.remove("Database");

        // Remove mapping
        studentCourseMap.remove("Priya");

        System.out.println("\nAfter Deletion:");
        System.out.println("================");

        System.out.println("Students: " + studentList);

        System.out.println("Courses: " + courseSet);

        System.out.println("Mappings: " + studentCourseMap);
    }
}
