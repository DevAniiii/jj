// Java Program for Simple Banking System using Interface and Polymorphism

interface Account {

    void deposit(double amount);

    void withdraw(double amount);

    void display();
}

// Savings Account Class
class SavingsAccount implements Account {

    int accNo;
    String name;
    double balance;

    // Constructor
    SavingsAccount(int accNo, String name, double balance) {
        this.accNo = accNo;
        this.name = name;
        this.balance = balance;
    }

    // Deposit Method
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Amount Deposited: " + amount);
    }

    // Withdraw Method
    public void withdraw(double amount) {

        // Minimum balance validation
        if (balance - amount >= 1000) {
            balance -= amount;
            System.out.println("Amount Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient Balance! Minimum balance should be 1000.");
        }
    }

    // Display Method
    public void display() {
        System.out.println("Savings Account");
        System.out.println("Account Number : " + accNo);
        System.out.println("Account Holder : " + name);
        System.out.println("Balance        : " + balance);
    }
}

// Current Account Class
class CurrentAccount implements Account {

    int accNo;
    String name;
    double balance;

    // Constructor
    CurrentAccount(int accNo, String name, double balance) {
        this.accNo = accNo;
        this.name = name;
        this.balance = balance;
    }

    // Deposit Method
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Amount Deposited: " + amount);
    }

    // Withdraw Method
    public void withdraw(double amount) {

        // Withdrawal validation
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Amount Withdrawn: " + amount);
        } else {
            System.out.println("Insufficient Balance!");
        }
    }

    // Display Method
    public void display() {
        System.out.println("Current Account");
        System.out.println("Account Number : " + accNo);
        System.out.println("Account Holder : " + name);
        System.out.println("Balance        : " + balance);
    }
}

// Main Class
public class bank2 {

    public static void main(String[] args) {

        // Interface reference for polymorphism
        Account acc;

        // Savings Account Object
        acc = new SavingsAccount(1001, "Rahul", 5000);

        acc.display();
        acc.deposit(2000);
        acc.withdraw(5500);

        System.out.println("----------------------------");

        // Current Account Object
        acc = new CurrentAccount(2001, "Amit", 8000);

        acc.display();
        acc.deposit(3000);
        acc.withdraw(12000);
    }
}