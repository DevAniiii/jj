// Java Program to Maintain Employee Directory using Vector

import java.util.Vector;
import java.util.Enumeration;

// Employee Class
class Employee {

    int empId;
    String name;

    // Constructor
    Employee(int empId, String name) {
        this.empId = empId;
        this.name = name;
    }

    // Display Method
    void display() {
        System.out.println("Employee ID   : " + empId);
        System.out.println("Employee Name : " + name);
        System.out.println("-------------------------");
    }
}

public class employeevector {

    public static void main(String[] args) {

        /*
         * Vector is thread-safe because its methods are synchronized.
         * Multiple threads can access Vector safely.
         * However, it is slower than ArrayList due to synchronization overhead.
         */

        // Create Vector
        Vector<Employee> employees = new Vector<Employee>();

        // Adding elements
        employees.add(new Employee(101, "Rahul"));
        employees.add(new Employee(102, "Amit"));
        employees.add(new Employee(103, "Priya"));

        System.out.println("EMPLOYEE DIRECTORY");
        System.out.println("======================");

        // Traversing using Enumeration
        Enumeration<Employee> e = employees.elements();

        while (e.hasMoreElements()) {

            Employee emp = e.nextElement();
            emp.display();
        }

        // Updating an element
        employees.set(1, new Employee(102, "Rohan"));

        System.out.println("\nAfter Updating Employee:");
        System.out.println("======================");

        Enumeration<Employee> e2 = employees.elements();

        while (e2.hasMoreElements()) {

            Employee emp = e2.nextElement();
            emp.display();
        }

        // Removing an element
        employees.remove(2);

        System.out.println("\nAfter Removing Employee:");
        System.out.println("======================");

        Enumeration<Employee> e3 = employees.elements();

        while (e3.hasMoreElements()) {

            Employee emp = e3.nextElement();
            emp.display();
        }
    }
}