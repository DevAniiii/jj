class AccessDemo {

    // Public data member
    public int publicVar = 10;

    // Private data member
    private int privateVar = 20;

    // Default data member
    int defaultVar = 30;

    // Public method
    public void showPublic() {
        System.out.println("Public Variable: " + publicVar);
    }

    // Private method
    private void showPrivate() {
        System.out.println("Private Variable: " + privateVar);
    }

    // Default method
    void showDefault() {
        System.out.println("Default Variable: " + defaultVar);
    }

    // Public method to access private method
    public void accessPrivate() {
        showPrivate();
    }
}

public class pb_pv_df {

    public static void main(String[] args) {

        // Creating object
        AccessDemo obj = new AccessDemo();

        // Accessing public member
        System.out.println("Accessing Public Member:");
        obj.showPublic();

        // Accessing default member
        System.out.println("\nAccessing Default Member:");
        obj.showDefault();

        // Accessing private member through public method
        System.out.println("\nAccessing Private Member:");
        obj.accessPrivate();

        // Direct access to private variable or method is not allowed
        // obj.privateVar;      // Error
        // obj.showPrivate();  // Error
    }
}