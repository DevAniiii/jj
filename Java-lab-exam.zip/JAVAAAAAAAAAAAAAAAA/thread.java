// Java Program to Create Multiple Threads by Extending Thread Class

class MyThread extends Thread {

    String taskName;

    // Constructor
    MyThread(String taskName) {
        this.taskName = taskName;
    }

    // Thread execution
    public void run() {

        try {

            for (int i = 1; i <= 5; i++) {

                System.out.println(taskName +
                        " is running : Step " + i);

                // Sleep for 1 second
                Thread.sleep(1000);
            }

        }

        catch (InterruptedException e) {

            System.out.println(taskName +
                    " interrupted.");
        }

        // Thread termination message
        System.out.println(taskName +
                " has finished execution.");
    }
}

public class thread {

    public static void main(String[] args) {

        // Creating threads
        MyThread t1 = new MyThread("Task-1");
        MyThread t2 = new MyThread("Task-2");
        MyThread t3 = new MyThread("Task-3");

        // Setting thread priorities
        t1.setPriority(Thread.MIN_PRIORITY);   // Priority 1
        t2.setPriority(Thread.NORM_PRIORITY);  // Priority 5
        t3.setPriority(Thread.MAX_PRIORITY);   // Priority 10

        // Display priorities
        System.out.println("Task-1 Priority : " +
                t1.getPriority());

        System.out.println("Task-2 Priority : " +
                t2.getPriority());

        System.out.println("Task-3 Priority : " +
                t3.getPriority());

        // Starting threads
        t1.start();
        t2.start();
        t3.start();

        System.out.println("\nThreads Started...\n");
    }
}