// Employee Management System using Inheritance and Runtime Polymorphism

class Employee {
    int empId;
    String name;
    double basicSalary;

    // Default constructor
    Employee() {
        empId = 0;
        name = "Unknown";
        basicSalary = 0;
    }

    // Parameterized constructor
    Employee(int empId, String name, double basicSalary) {
        this.empId = empId;
        this.name = name;
        this.basicSalary = basicSalary;
    }

    // Method to calculate salary
    double calculateSalary() {
        return basicSalary;
    }

    // Display employee details
    void display() {
        System.out.println("Employee ID : " + empId);
        System.out.println("Employee Name : " + name);
        System.out.println("Basic Salary : " + basicSalary);
        System.out.println("Total Salary : " + calculateSalary());
    }
}

// Derived class PermanentEmployee
class PermanentEmployee extends Employee {
    double hra;
    double da;

    // Constructor
    PermanentEmployee(int empId, String name, double basicSalary,
                      double hra, double da) {
        super(empId, name, basicSalary);
        this.hra = hra;
        this.da = da;
    }

    // Overriding calculateSalary()
    @Override
    double calculateSalary() {
        return basicSalary + hra + da;
    }
}

// Derived class ContractEmployee
class ContractEmployee extends Employee {
    int workingDays;
    double dailyWage;

    // Constructor
    ContractEmployee(int empId, String name,
                     int workingDays, double dailyWage) {
        super(empId, name, 0);
        this.workingDays = workingDays;
        this.dailyWage = dailyWage;
    }

    // Overriding calculateSalary()
    @Override
    double calculateSalary() {
        return workingDays * dailyWage;
    }
}

// Main class
public class employee2 {
    public static void main(String[] args) {

        // Runtime Polymorphism
        Employee emp;

        // Permanent Employee object
        emp = new PermanentEmployee(101, "Rohan", 30000, 5000, 3000);

        System.out.println("Permanent Employee Details");
        emp.display();

        System.out.println("----------------------------");

        // Contract Employee object
        emp = new ContractEmployee(102, "Amit", 25, 1200);

        System.out.println("Contract Employee Details");
        emp.display();
    }
}