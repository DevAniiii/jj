// Java Program to Manage Book Information using HashSet

import java.util.HashSet;

// Book Class
class Book {

    int bookId;
    String title;
    String author;

    // Constructor
    Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    // Override equals() method
    @Override
    public boolean equals(Object obj) {

        if (this == obj)
            return true;

        if (obj == null || getClass() != obj.getClass())
            return false;

        Book b = (Book) obj;

        return bookId == b.bookId;
    }

    // Override hashCode() method
    @Override
    public int hashCode() {
        return bookId;
    }

    // Display Method
    void display() {

        System.out.println("Book ID   : " + bookId);
        System.out.println("Title     : " + title);
        System.out.println("Author    : " + author);
        System.out.println("--------------------------");
    }
}

public class book {

    public static void main(String[] args) {

        // Create HashSet
        HashSet<Book> books = new HashSet<Book>();

        // Add Book Objects
        books.add(new Book(101, "Java Programming", "James Gosling"));
        books.add(new Book(102, "Data Structures", "Mark Allen"));
        books.add(new Book(103, "Operating System", "Galvin"));

        // Duplicate Book ID
        books.add(new Book(101, "Java Programming", "James Gosling"));

        System.out.println("UNIQUE BOOK RECORDS");
        System.out.println("========================");

        // Display unique books
        for (Book b : books) {
            b.display();
        }
    }
}