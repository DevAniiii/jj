// Java Program: Multiple Threads Performing Arithmetic Operations
// with Exception Handling

class ArithmeticThread extends Thread {

    int num1, num2;

    // Constructor
    ArithmeticThread(String threadName, int num1, int num2) {
        super(threadName);
        this.num1 = num1;
        this.num2 = num2;
    }

    // Thread execution
    public void run() {

        try {

            System.out.println("\n" + getName() + " Started");

            // Arithmetic operation
            int result = num1 / num2;

            System.out.println(getName() +
                    " Result: " + result);

        }

        // Handle division by zero
        catch (ArithmeticException e) {

            System.out.println(getName() +
                    " Exception: " + e.getMessage());
        }

        // Handle any other exception
        catch (Exception e) {

            System.out.println(getName() +
                    " Error: " + e.getMessage());
        }

        // Thread termination
        finally {

            System.out.println(getName() +
                    " Finished Execution");
        }
    }
}

public class thread2 {

    public static void main(String[] args) {

        // Creating multiple threads
        ArithmeticThread t1 =
                new ArithmeticThread("Thread-1", 20, 5);

        ArithmeticThread t2 =
                new ArithmeticThread("Thread-2", 10, 0);

        ArithmeticThread t3 =
                new ArithmeticThread("Thread-3", 30, 3);

        ArithmeticThread t4 =
                new ArithmeticThread("Thread-4", 50, 0);

        // Starting threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();

        System.out.println("Main Thread Continues Execution...");
    }
}
