import java.util.Scanner;

public class palindrome {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Input number
        System.out.print("Enter an integer number: ");
        int num = sc.nextInt();

        int original = num;
        int reverse = 0;

        // Reverse the number using while loop
        while (num != 0) {
            int digit = num % 10;
            reverse = reverse * 10 + digit;
            num = num / 10;
        }

        // Display reversed number
        System.out.println("Reversed number: " + reverse);

        // Check palindrome
        if (original == reverse) {
            System.out.println(original + " is a Palindrome number.");
        } else {
            System.out.println(original + " is not a Palindrome number.");
        }

        sc.close();
    }
}