// Java Program for Simple Banking System using Exception Handling

import java.util.Scanner;

// User-defined Exception
class InsufficientBalanceException extends Exception {

    InsufficientBalanceException(String message) {
        super(message);
    }
}

class BankAccount {

    double balance;

    // Constructor
    BankAccount(double balance) {
        this.balance = balance;
    }

    // Deposit Method
    void deposit(double amount) {

        balance += amount;

        System.out.println("Deposited Amount: " + amount);
        System.out.println("Current Balance : " + balance);
    }

    // Withdraw Method with throws
    void withdraw(double amount)
            throws InsufficientBalanceException {

        if (amount > balance) {

            throw new InsufficientBalanceException(
                "Insufficient Balance! Withdrawal failed."
            );
        }

        balance -= amount;

        System.out.println("Withdrawn Amount: " + amount);
        System.out.println("Current Balance : " + balance);
    }
}

public class bank3 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        try {

            // Create account
            BankAccount acc = new BankAccount(5000);

            // Deposit
            System.out.print("Enter deposit amount: ");
            double depositAmount = sc.nextDouble();

            acc.deposit(depositAmount);

            // Withdraw
            System.out.print("\nEnter withdrawal amount: ");
            double withdrawAmount = sc.nextDouble();

            acc.withdraw(withdrawAmount);
        }

        // Multiple catch blocks

        catch (InsufficientBalanceException e) {
            System.out.println("\nException: " + e.getMessage());
        }

        catch (ArithmeticException e) {
            System.out.println("\nArithmetic Error Occurred!");
        }

        catch (Exception e) {
            System.out.println("\nInvalid Input!");
        }

        finally {
            sc.close();
            System.out.println("\nProgram Ended.");
        }
    }
}