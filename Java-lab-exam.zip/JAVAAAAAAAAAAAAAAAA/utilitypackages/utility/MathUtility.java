// File: utility/MathUtility.java

package utilitypackages.utility;

public class MathUtility {

    // Public static methods
    public static int add(int a, int b) {
        return a + b;
    }

    public static int subtract(int a, int b) {
        return a - b;
    }

    public static int multiply(int a, int b) {
        return a * b;
    }

    public static int divide(int a, int b) {

        if (b == 0) {
            System.out.println("Division by zero is not allowed.");
            return 0;
        }

        return a / b;
    }

}