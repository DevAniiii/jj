class Student {

    // Data members
    int rollNo;
    String name;
    double marks;

    // Method to assign values
    void setData(int r, String n, double m) {
        rollNo = r;
        name = n;
        marks = m;
    }

    // Method to display values
    void display() {
        System.out.println("Roll No: " + rollNo);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
        System.out.println();
    }
}

public class objects {

    public static void main(String[] args) {

        // Creating first object
        Student s1 = new Student();
        s1.setData(101, "Rahul", 85.5);

        // Creating second object
        Student s2 = new Student();
        s2.setData(102, "Anita", 91.0);

        // Creating third object
        Student s3 = new Student();
        s3.setData(103, "Karan", 78.5);

        // Displaying details of each object
        System.out.println("Student 1 Details:");
        s1.display();

        System.out.println("Student 2 Details:");
        s2.display();

        System.out.println("Student 3 Details:");
        s3.display();
    }
}